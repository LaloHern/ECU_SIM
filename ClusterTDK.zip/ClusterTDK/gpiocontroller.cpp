#include "gpiocontroller.h"
#include <wiringPi/wiringPi.h>
#include <wiringPi/wiringPiSPI.h>
#include <QDebug>

GPIOController::GPIOController():
    can(0, 500000, 6),
    m_pollTimer(this),
    m_canMsgData({0,0,0,0,0,0,0,0})
{
    //*class instance of MCP CAN*//
    //initializing SPI parameters
    // SPI0
    // baudrate 500 kbit/s
    // interrupt pin 25 (BCM 6)
    wiringPiSetup();
    can.setupSpi();
    can.setupInterruptGpio();
    can.begin(MCP_NORMAL, CAN_500KBPS, MCP_8MHZ);
    can.setMode(MCP_NORMAL);

    m_pollTimer.setInterval(80);
    m_pollTimer.setSingleShot(false);

    QObject::connect(&m_pollTimer, SIGNAL(timeout()), this, SLOT(pollLoop()));

    m_pollTimer.start();
}

void GPIOController::pollLoop() {
    can.readMsgBuf(&m_canMsgId, &m_canMsgDLC, m_canMsgData);

    setSpeed(m_canMsgData[0]);
    setEngineRpm(m_canMsgData[1]);
    setEngineTemp(m_canMsgData[2]);
    setFuelLevel(m_canMsgData[3]);
    setLeftTurnLight(m_canMsgData[4]);
    setRightTurnLight(m_canMsgData[5]);

    m_pollTimer.start();
}

INT8U GPIOController::canMsg() {
    return m_canMsgData[0];
}

void GPIOController::writeCANMsg(INT32U id, INT8U len) {
    can.sendMsgBuf(id, len, m_canMsgData);
}

void GPIOController::setMsgPayload(int index, int dataBite) {
    m_canMsgData[index] = dataBite;
}

void GPIOController::setSpeed (int value) {
    if (m_speed != value) {
        m_speed = value;
        emit speedChanged();
    }
}

void GPIOController::setEngineRpm (int value) {
    if (m_engineRpm != value) {
        m_engineRpm = value;
        emit engineRpmChanged();
    }
}

void GPIOController::setEngineTemp (int value) {
    if (m_engineTemp != value) {
        m_engineTemp = value;
        emit engineTempChanged();
    }
}

void GPIOController::setFuelLevel (int value) {
    if (m_fuelLevel != value) {
        m_fuelLevel = value;
        emit fuelLevelChanged();
    }
}

void GPIOController::setLeftTurnLight (bool value) {
    if (m_rightTurnLight != value) {
        m_rightTurnLight = value;
        emit leftTurnLightChanged();
    }
}

void GPIOController::setRightTurnLight (bool value) {
    if (m_leftTurnLight != value) {
        m_leftTurnLight = value;
        emit rightTurnLightChanged();
    }
}

int GPIOController::speed() {
    return m_speed;
}

int GPIOController::engineRpm() {
    return m_engineRpm;
}

int GPIOController::engineTemp() {
    return m_engineTemp;
}

int GPIOController::fuelLevel() {
    return m_fuelLevel;
}

bool GPIOController::leftTurnLight() {
    return m_leftTurnLight;
}

bool GPIOController::rightTurnLight() {
    return m_rightTurnLight;
}
